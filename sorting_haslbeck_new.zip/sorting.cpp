//Chris Haslbeck
#include <iostream>
#include "sorting.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

using namespace std;

//Constructor
sorting::sorting() {
	/*Can leave blank*/
}

//Fill Array method
void sorting::fillArray(){

	int i;
	srand(time(NULL));
	cout << "Your random numbers are:" << "\n";
	for(i=0;i<20;i++){
		array[i] = rand()%50;
	}
}

//toString method
void sorting::toString() {

	int i;
	for(i=0;i<20;i++){
		cout << array[i] << "\n";
	}

}

void sorting::SelectionSort() {

	int temp;
	int min;
	int i;
	int j;

	for(i=0;i<20-1;i++){
		min = i;
		for(j=i+1;j<20;j++){
			if(array[j]<array[min]){
				min=j;
			}
		}

		temp=array[i];
		array[i]=array[min];
		array[min]=temp;
	}
}

void sorting::BubbleSort(){

        int tmp;
        int i;
        int j;
	for(i=0;i<20-1;i++){
		for(j=i+1;j<20;j++){
			if(array[i] > array[j]){
				tmp = array[i];
                                array[i] = array[j];
                                array[j] = tmp;
			}
		}
	}

}

void sorting::InsertionSort(){

	int j;
	int i;
	int temp;
	for(i=0;i<20;i++){
		j=i;
		while(j<i && array[j] < array[j-1]){
			temp=array[j];
			array[j]=array[j-1];
			array[j-1]=temp;
			j--;
		}
	}

}

int main() {

	//Creates a sorting object
	sorting sort;

	sort.fillArray();
	sort.toString();
	sort.SelectionSort();
        cout << endl << endl << endl << "Your sorted numbers using selection sort are:" << endl;
	sort.toString();

	cout << endl << endl;

	sort.fillArray();
	sort.toString();
	sort.BubbleSort();
        cout << endl << endl << endl << "Your sorted numbers using bubble sort are:" << endl;
	sort.toString();

	cout << endl << endl;

	sort.fillArray();
	sort.toString();
	sort.InsertionSort();
	cout << endl << endl << endl << "Your sorted numbers using insertion sort are:" << endl;
	sort.toString();

	cout << endl << endl;

	return 0;
}
