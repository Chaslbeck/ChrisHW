using namespace std;
class sorting{
	public:
		sorting();
		void fillArray(); //Fills the array with random numbers
		void toString();  //Prints the array
		void SelectionSort(); //Sorts the array
		void BubbleSort();
		void InsertionSort();
		void QuickSort();
	private:
		int array[20];
};



